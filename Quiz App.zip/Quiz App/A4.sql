create database quiz_ads;
use quiz_ads;

show tables;

INSERT INTO USERS (user_id, password, type) VALUES
('1', '1234', 'faculty'),
('2', '1234', 'faculty'),
('3', '1234', 'faculty');


INSERT INTO USERS (user_id, password, type) VALUES
('21510045', '1234', 'student'),
('22520005', '1234', 'student'),
('22520006', '1234', 'student');

select * from quiz;
select * from questions;
