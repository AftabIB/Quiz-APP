import axios from "axios";
import { useNavigate } from "react-router-dom";

function AddNewQuiz() {
  const navigate = useNavigate();

  const handleSubmit = (event) => {
    event.preventDefault();
    axios
      .post("http://localhost:5000/quiz", {
        quiz_id: event.target.quiz_id.value,
        quiz_description: event.target.quiz_description.value,
        user_id: "xyz",
        quiz_password: "1234",
      })
      .then((res) => {
        alert("Quiz created successfully!!!");
        event.target.reset();
        console.log("Res", res);
        navigate("/"); // Redirect to the home page
      })
      .catch((err) => {
        console.log("Err", err);
      });
  };

  const handleGoBack = () => {
    navigate("/Home"); // Redirect to the home page
  };

  return (
    <div
      style={{
        backgroundColor: "#0d1117",
        color: "white",
        fontSize: "20px",
        padding: "25px",
        height: "100vh",
      }}
    >
      <h2>Add New Quiz</h2>
      <form onSubmit={handleSubmit}>
        <label htmlFor="quiz_id">Enter Quiz Id : </label>
        <input
          type="text"
          id="quiz_id"
          name="quiz_id"
          style={{
            marginBottom: "10px",
            padding: "5px",
            borderRadius: "5px",
            width: "100%",
          }}
        />
        <br />
        <label htmlFor="quiz_description">Enter Quiz description : </label>
        <input
          type="text"
          id="quiz_description"
          name="quiz_description"
          style={{
            marginBottom: "10px",
            padding: "5px",
            borderRadius: "5px",
            width: "100%",
          }}
        />
        <br />
        <button
          type="submit"
          style={{
            width: "150px",
            backgroundColor: "#2ea44f",
            color: "#ffffff",
            borderRadius: "5px",
            height: "40px",
            transition: "all 0.3s ease",
            border: "none",
            cursor: "pointer",
            marginRight: "10px",
          }}
        >
          Submit
        </button>
        <button
          onClick={handleGoBack}
          style={{
            width: "150px",
            backgroundColor: "#2ea44f",
            color: "#ffffff",
            borderRadius: "5px",
            height: "40px",
            transition: "all 0.3s ease",
            border: "none",
            cursor: "pointer",
          }}
        >
          Go Home
        </button>
      </form>
    </div>
  );
}

export default AddNewQuiz;
