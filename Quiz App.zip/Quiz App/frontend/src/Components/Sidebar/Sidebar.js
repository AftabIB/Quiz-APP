import React, { useState } from "react";
import { Button, Typography, Drawer } from "@material-ui/core";
import { useNavigate } from "react-router-dom";

function Sidebar() {
  const navigate = useNavigate();
  const logout = () => {
    localStorage.setItem("loggedin", false);
    navigate("/");
  };

  const [isOpen, setIsOpen] = useState(false);

  return (
    <>
      <Drawer open={isOpen} onClose={() => setIsOpen(false)}>
        <div
          style={{
            width: 150,
            display: "flex",
            flexDirection: "column",
          }}
        >
          <br />
          <Button onClick={() => setIsOpen(false)}>Close</Button>
          <Button href="/Home">Home</Button>
          <Button href="/AllQuizPage">Select a quiz</Button>
          <Button href="/" onClick={logout}>
            Logout
          </Button>
        </div>
      </Drawer>

      <div
        style={{
          backgroundColor: "black",
          display: "flex",
          alignItems: "center",
          padding: "20px",
        }}
      >
        <Button
          onClick={() => setIsOpen(true)}
          style={{ color: "white", fontSize: "1.5rem", marginRight: "20px" }}
        >
          ☰
        </Button>
        <Typography
          variant="h4"
          style={{ color: "white", fontFamily: "Times New Roman" }}
        >
          Advanced Database System Lab Assignment
        </Typography>
      </div>
    </>
  );
}

export default Sidebar;
