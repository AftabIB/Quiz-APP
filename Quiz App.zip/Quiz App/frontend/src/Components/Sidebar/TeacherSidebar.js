import React, { useState } from "react";
import { Button, Typography, Drawer } from "@material-ui/core";
import { useNavigate } from "react-router-dom";
import { makeStyles } from "@material-ui/core/styles";

const useStyles = makeStyles((theme) => ({
  drawer: {
    width: 200,
    alignItems: "center",
  },
  closeButton: {
    marginBottom: theme.spacing(1),
  },
  sidebarButton: {
    marginBottom: theme.spacing(1),
    display: "block",
  },
  navbar: {
    backgroundColor: "black",
    display: "flex",
    alignItems: "center",
    padding: "20px",
  },
}));

function TeacherSidebar() {
  const classes = useStyles();
  const navigate = useNavigate();
  const logout = () => {
    localStorage.setItem("loggedin", false);
    navigate("/");
  };

  const [isOpen, setIsOpen] = useState(false);

  const handleClose = () => {
    setIsOpen(false);
  };

  return (
    <>
      <Drawer open={isOpen} onClose={() => setIsOpen(false)}>
        <div className={classes.drawer}>
          <br />
          <Button onClick={handleClose} className={classes.closeButton}>
            Close
          </Button>
          <Button href="/Home" className={classes.sidebarButton}>
            Home
          </Button>
          <Button href="/AddNewQuiz" className={classes.sidebarButton}>
            Add New Quiz
          </Button>
          <Button href="/TeacherViewNew" className={classes.sidebarButton}>
            Add New Question
          </Button>
          {/* <Button href="/TeacherViewUpdate" className={classes.sidebarButton}>
            Update Existing Question
          </Button> */}
          <Button href="/" onClick={logout} className={classes.sidebarButton}>
            Logout
          </Button>
        </div>
      </Drawer>

      <div className={classes.navbar}>
        <Button
          onClick={() => setIsOpen(true)}
          style={{ color: "white", fontSize: "1.5rem", marginRight: "20px" }}
        >
          ☰
        </Button>
        <Typography
          variant="h4"
          style={{ color: "white", fontFamily: "Times New Roman" }}
        >
          Walchand College Of Engineering, Sangli
        </Typography>
      </div>
    </>
  );
}

export default TeacherSidebar;
