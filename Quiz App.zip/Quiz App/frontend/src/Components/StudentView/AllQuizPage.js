import axios from "axios";
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import Sidebar from "../Sidebar/Sidebar";
import { makeStyles } from "@material-ui/core/styles";
import Button from "@material-ui/core/Button";

const useStyles = makeStyles((theme) => ({
  button: {
    width: "30%",
    marginRight: theme.spacing(2),
    marginBottom: theme.spacing(2),
    backgroundColor: "#2ea44f",
    color: "#ffffff",
    borderRadius: "5px",
    height: "45px",
    transition: "all 0.3s ease",
    "&:hover": {
      backgroundColor: "#238636",
      boxShadow: "0px 5px 5px rgba(0, 0, 0, 0.3)",
      transform: "translateY(-5px)",
    },
  },
}));

function AllQuizPage() {
  const navigate = useNavigate();
  const [quizArray, setQuizArray] = useState([]);
  const classes = useStyles();

  useEffect(() => {
    axios
      .get("http://localhost:5000/quiz")
      .then((res) => {
        console.log("RES", res.data);
        const quizButtons = res.data.map((quiz) => (
          <Button
            key={quiz.quiz_id}
            className={classes.button}
            onClick={() =>
              navigate("/quiz/" + quiz.quiz_id, {
                state: {
                  quiz_id: quiz.quiz_id,
                  user_id: quiz.user_id,
                },
              })
            }
          >
            {quiz.quiz_id}
          </Button>
        ));
        setQuizArray(quizButtons);
      })
      .catch((err) => {
        console.log("ERR", err);
      });
  }, [classes.button, navigate]);

  return (
    <>
      <Sidebar />
      <div
        style={{
          textAlign: "center",
          fontFamily: "times new roman",
          marginTop: "0",
          color: "black",
          backgroundColor: "#0d1117",
          minHeight: "87.5vh",
          display: "flex",
          flexDirection: "column",
          justifyContent: "center",
          alignItems: "center",
          overflow: "hidden",
        }}
      >
        {quizArray}
      </div>
    </>
  );
}

export default AllQuizPage;
