import axios from "axios";
import { useEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";

function Scorecard() {
  const navigate = useNavigate();
  const { state } = useLocation();
  const [score, setScore] = useState(0);

  useEffect(() => {
    axios
      .post("http://localhost:5000/questions/calculateAnswer", {
        question: state.answerSheet,
      })
      .then((res) => {
        console.log("Res", res);
        setScore(res.data.correct);
      })
      .catch((err) => {
        console.log("Err", err);
      });
  }, [state.answerSheet]);

  const handleRedirect = () => {
    navigate("/AllQuizPage");
  };

  return (
    <div
      style={{
        backgroundColor: "black",
        color: "white",
        padding: "25px",
        minHeight: "100vh", // Make background full-screen
      }}
    >
      <h1>Your total score is {score}</h1>
      <button
        onClick={handleRedirect}
        style={{
          backgroundColor: "#2ea44f",
          color: "#ffffff",
          borderRadius: "5px",
          padding: "10px 20px",
          marginTop: "20px",
          cursor: "pointer",
        }}
      >
        Go to All Quizzes
      </button>
    </div>
  );
}
export default Scorecard;
