import axios from "axios";
import React, { useEffect, useState } from "react";
import { makeStyles } from "@material-ui/core/styles";
import Button from "@material-ui/core/Button";
import Select from "react-select";
import TeacherSidebar from "./Sidebar/TeacherSidebar";
import { useNavigate } from "react-router-dom";

const useStyles = makeStyles((theme) => ({
  button: {
    width: "15%",
    backgroundColor: "#2ea44f",
    color: "#ffffff",
    borderRadius: "5px",
    height: "40px",
    transition: "all 0.3s ease",
    "&:hover": {
      backgroundColor: "#238636",
      boxShadow: "0px 3px 3px rgba(0, 0, 0, 0.3)",
    },
    float: "left", // Align button to the left
    marginRight: "10px",
  },
  textarea: {
    width: "100%",
    marginBottom: theme.spacing(1),
    padding: theme.spacing(1),
    borderRadius: "5px",
    border: "1px solid #ccc",
    backgroundColor: "#0d1117",
    color: "white",
    fontSize: "16px",
  },
  input: {
    width: "100%",
    marginBottom: theme.spacing(1),
    padding: theme.spacing(1),
    borderRadius: "5px",
    border: "1px solid #ccc",
    backgroundColor: "#0d1117",
    color: "white",
    fontSize: "16px",
  },
  select: {
    width: "50%",
    marginBottom: theme.spacing(1),
    fontSize: "18px", // Increase font size
    "& .react-select__control": {
      backgroundColor: "#0d1117",
      color: "#0d1117", // Change text color to #0d1117
      border: "1px solid #ccc",
      borderRadius: "5px",
    },
    "& .react-select__single-value": {
      color: "#0d1117", // Change text color to #0d1117
    },
  },
  root: {
    backgroundColor: "#0d1117",
    minHeight: "100vh", // Ensure the background color fills the entire screen
  },
}));

function TeacherViewNew(props) {
  const classes = useStyles();
  const navigate = useNavigate();
  const [quizOptions, setQuizOptions] = useState([]);
  const [selectedOption, setSelectedOption] = useState("");

  const [finalData, setFinalData] = useState({
    description: "",
    option1: "",
    option2: "",
    option3: "",
    option4: "",
    answer: "",
    author: "xyz",
    quiz_id: "",
  });

  useEffect(() => {
    axios
      .get("http://localhost:5000/quiz")
      .then((res) => {
        console.log("Res", res);
        const options = res.data.map((quiz) => ({
          label: quiz.quiz_id,
          value: quiz.quiz_id,
        }));
        setQuizOptions(options);
      })
      .catch((err) => {
        console.log("Err", err);
      });
  }, []);

  function handleClick(event) {
    if (selectedOption === "") {
      alert("Select a Quiz");
      return;
    }
    event.preventDefault();

    axios
      .post("http://localhost:5000/questions", finalData)
      .then((res) => {
        alert("Question created successfully!!!");
        window.location.reload();
        console.log("res", res.data);
        navigate("/"); // Redirect to the home page
      })
      .catch((err) => {
        console.log(err);
      });
  }

  const handleGoBack = () => {
    navigate("/Home"); // Redirect to the home page
  };

  return (
    <div className={classes.root}>
      <TeacherSidebar />
      <div
        className="TeacherView"
        style={{ color: "white", fontSize: "15px", padding: "25px" }}
      >
        <h2 style={{ textAlign: "center", margin: "0" }}>Add New Question</h2>
        <h3>Enter Question </h3>
        <textarea
          className={classes.textarea}
          cols="100"
          rows="2"
          onChange={(event) =>
            setFinalData({ ...finalData, description: event.target.value })
          }
        ></textarea>
        <input
          className={classes.input}
          type="text"
          placeholder="  Option 1"
          onChange={(event) =>
            setFinalData({ ...finalData, option1: event.target.value })
          }
        />
        <input
          className={classes.input}
          type="text"
          placeholder="  Option 2"
          onChange={(event) =>
            setFinalData({ ...finalData, option2: event.target.value })
          }
        />
        <input
          className={classes.input}
          type="text"
          placeholder="  Option 3"
          onChange={(event) =>
            setFinalData({ ...finalData, option3: event.target.value })
          }
        />
        <input
          className={classes.input}
          type="text"
          placeholder="  Option 4"
          onChange={(event) =>
            setFinalData({ ...finalData, option4: event.target.value })
          }
        />
        <input
          className={classes.input}
          type="text"
          placeholder="Enter answer(option number)"
          onChange={(event) =>
            setFinalData({ ...finalData, answer: event.target.value })
          }
        />
        <div style={{ textAlign: "left" }}>
          <Select
            placeholder="Select a quiz"
            className={classes.select}
            options={quizOptions}
            onChange={(option) => {
              setSelectedOption(option.value);
              setFinalData({ ...finalData, quiz_id: option.value });
            }}
            styles={{
              control: (provided) => ({
                ...provided,
                backgroundColor: "#0d1117", // Dark background color
                border: "1px solid #fff", // Dark border color
                borderRadius: "5px",
              }),
              singleValue: (provided) => ({
                ...provided,
                color: "#fff", // Text color
              }),
              indicatorSeparator: (provided) => ({
                ...provided,
                backgroundColor: "#0d1117", // Separator color
              }),
              menu: (provided) => ({
                ...provided,
                backgroundColor: "#333", // Menu background color
                border: "1px solid #0d1117", // Menu border color
                color: "#fff", // Menu text color
              }),
              option: (provided) => ({
                ...provided,
                color: "#fff", // Option text color
              }),
              option: (provided, state) => ({
                ...provided,
                backgroundColor: state.isSelected ? "#0d1117" : null, // Selected option background color
                "&:hover": {
                  backgroundColor: "#0d1117", // Hovered option background color
                },
              }),
            }}
          />
        </div>
        <br />
        <Button className={classes.button} onClick={handleClick}>
          Add
        </Button>
        <Button className={classes.button} onClick={handleGoBack}>
          Go Home
        </Button>
      </div>
    </div>
  );
}

export default TeacherViewNew;
