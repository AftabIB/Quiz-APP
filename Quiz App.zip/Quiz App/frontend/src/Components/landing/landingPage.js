import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import Button from "@material-ui/core/Button";
import Typography from "@material-ui/core/Typography";

const useStyles = makeStyles((theme) => ({
  root: {
    backgroundColor: "#0d1117",
    color: "#c9d1d9",
    textAlign: "center",
    minHeight: "100vh", // Ensure full viewport height
    display: "flex",
    flexDirection: "column",
    justifyContent: "center",
    alignItems: "center",
  },
  button: {
    textTransform: "capitalize",
    margin: theme.spacing(1),
    backgroundColor: "#2ea44f",
    fontSize: "16px",
    color: "#c9d1d9",
    width: "140px",
    height: "45px",
    transition: "all 0.3s ease",
    "&:hover": {
      backgroundColor: "#238636",
      boxShadow: "0px 5px 5px rgba(0, 0, 0, 0.3)",
      transform: "translateY(-5px)",
    },
  },
  text: {
    textAlign: "Justifycenter",
    padding: theme.spacing(3),
    fontSize: "16px",
  },
  img: {
    width: "28%",
  },
}));

function Landing() {
  const classes = useStyles();

  return (
    <div className={classes.root}>
      <Typography variant="h4">
        Welcome to Walchand College of Engineering
      </Typography>
      <br />
      <img
        src="https://res.cloudinary.com/dzy2zn0mz/image/upload/v1707568814/WCEImage.jpg"
        alt="Walchand College of Engineering"
        className={classes.img}
      />
      <br />
      <div className="homeImg">
        <div style={{ padding: "5px" }}>
          <Button
            variant="contained"
            className={classes.button}
            href="/studentLogin"
          >
            Student Login
          </Button>
          <Button
            variant="contained"
            className={classes.button}
            href="/facultyLogin"
          >
            Faculty Login
          </Button>
        </div>

        <Typography variant="body1" className={classes.text}>
          Walchand College of Engineering is situated midway between Sangli and
          Miraj cities at Vishrambag, Sangli. The WCE campus is located on about
          90 acres of land on the southern side of Sangli - Miraj road. In 1947,
          the college made a modest beginning as New Engineering College, with a
          single program leading to B.E. (Civil) degree. In the year 1955, the
          College was renamed as Walchand College of Engineering as part of the
          new arrangements and pursuant to the Rehabilitation and Development
          Program mainly funded by Seth Walchand Hirachand Memorial Trust and
          the Government. The Government appointed an Ad Hoc Committee for
          conducting the college from May 1955, later replaced by the
          Administrative Council in 1956. The Ad Hoc Committee added two more
          degree programs in B.E. (Mechanical) and B.E. (Electrical) in 1955
          with the intake of 20 each. Three Diploma programs also started in
          1955 - Civil (40 intake), Mechanical (20) and Electrical (20).
        </Typography>
      </div>
    </div>
  );
}

export default Landing;
