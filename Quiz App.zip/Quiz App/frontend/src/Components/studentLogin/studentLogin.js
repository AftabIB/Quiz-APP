import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import Button from "@material-ui/core/Button";
import Typography from "@material-ui/core/Typography";
import TextField from "@material-ui/core/TextField";
import axios from "axios";
import { useNavigate } from "react-router-dom";

const useStyles = makeStyles((theme) => ({
  root: {
    backgroundColor: "#0d1117",
    minHeight: "100vh",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    padding: theme.spacing(2),
  },
  formContainer: {
    backgroundColor: "rgba(255, 255, 255, 0.1)",
    padding: theme.spacing(3),
    borderRadius: "10px",
    maxWidth: "500px",
    padding: "50px",
    width: "100%",
  },
  heading: {
    fontFamily: "times new roman",
    marginBottom: theme.spacing(2),
    fontSize: "24px",
    color: "#ffffff",
  },
  textField: {
    marginBottom: theme.spacing(2),
    paddingBottom: "10px",
  },
  submitButton: {
    backgroundColor: "#2ea44f",
    color: "#ffffff",
    borderRadius: "5px",
    height: "45px",
    transition: "all 0.3s ease",
    "&:hover": {
      backgroundColor: "#238636",
      boxShadow: "0px 5px 5px rgba(0, 0, 0, 0.3)",
      transform: "translateY(-5px)",
    },
  },
}));

function StudentLogin() {
  const classes = useStyles();
  const navigate = useNavigate();

  const handleSubmit = (event) => {
    event.preventDefault();
    const studentId = event.target.studentId.value;
    const password = event.target.password.value;

    axios
      .post("http://localhost:5000/login/student", {
        user_id: studentId,
        password,
      })
      .then((res) => {
        localStorage.setItem("loggedin", true);
        localStorage.setItem("userType", "student");
        console.log("Res", res);
        navigate("/AllQuizPage");
      })
      .catch((err) => {
        alert("Invalid Credentials");
        console.log("Err", err);
      });
  };

  return (
    <div className={classes.root}>
      <div className={classes.formContainer}>
        <Typography variant="h2" className={classes.heading}>
          Login as Student
        </Typography>
        <form onSubmit={handleSubmit}>
          <TextField
            type="text"
            name="studentId"
            label="Student ID"
            className={classes.textField}
            fullWidth
            InputProps={{ style: { color: "white" } }} // Set placeholder color
          />
          <TextField
            type="password"
            name="password"
            label="Password"
            className={classes.textField}
            fullWidth
            InputProps={{ style: { color: "white" } }} // Set placeholder color
          />
          <Button
            variant="contained"
            type="submit"
            className={classes.submitButton}
          >
            Submit
          </Button>
        </form>
      </div>
    </div>
  );
}

export default StudentLogin;
